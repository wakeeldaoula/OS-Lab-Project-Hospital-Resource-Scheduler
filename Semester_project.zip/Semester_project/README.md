# Hospital Resource Scheduler (Linux, C)

A modular OS project simulating hospital resource scheduling using CPU scheduling algorithms, POSIX threads, IPC (FIFO, POSIX message queues, POSIX shared memory), and synchronization via mutexes and semaphores.

## Features
- CPU Scheduling: FCFS, SJF, Priority, Round Robin.
- Multithreading: Each patient performs a service (consultation, lab test, treatment).
- Synchronization: Mutex + semaphores for doctors, machines, rooms.
- IPC: Logger process via `fork()` + `exec()`, communicates with scheduler through:
  - Named FIFO: `/tmp/hospital_log_fifo` for streaming log lines.
  - POSIX Message Queue: `/hospital_log_mq` for event notifications.
  - POSIX Shared Memory: `/hospital_stats` for final summary stats.
- Dynamic memory allocation for patient datasets.

## Prerequisites (Ubuntu VM)
- GCC, Make, POSIX threads, librt

For the console UI:
- Ncurses development headers

```bash
sudo apt-get update
sudo apt-get install -y build-essential libncurses-dev
```

## Build
Run in your Ubuntu VM (not in WSL):
```bash
cd Semester_project
make
```

## Quick Run
```bash
bin/hospital_scheduler --alg fcfs --patients 12 --doctors 3 --machines 2 --rooms 4 --quantum 3
```
## Console UI (Ncurses)
Build and launch the interactive console UI:
```bash
cd Semester_project
make run-ui
```
Features:
- Add, view, update, delete patients
- Configure resources (doctors/machines/rooms)
- Choose algorithm (FCFS/SJF/Priority/RR) and quantum
- Run scheduler and view metrics
- View logs (written by logger to `logs/log.txt`)

- Logs are written to `logs/log.txt` by the `bin/logger` process.
- The scheduler creates `/tmp/hospital_log_fifo`, `/hospital_log_mq`, and `/hospital_stats`.

## Arguments
- `--alg {fcfs|sjf|priority|rr}`: Choose CPU scheduling algorithm.
- `--patients N`: Number of patients (jobs) to generate.
- `--doctors N`, `--machines N`, `--rooms N`: Resource counts.
- `--quantum Q`: Time slice (ms) for Round Robin.

## Outputs
- Per-patient start/finish logs, resource usage events.
- Final report with average waiting time, average turnaround time, and algorithm comparison (if you run multiple modes).

## Clean
```bash
make clean
```

## Notes
- IPC objects are cleaned up on exit. If interrupted, you may need to remove `/tmp/hospital_log_fifo` or unlink MQ/SHM via reboot.
- All code targets standard Linux APIs. No Windows-specific calls.
