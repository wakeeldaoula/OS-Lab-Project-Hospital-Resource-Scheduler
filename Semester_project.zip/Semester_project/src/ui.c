#include <ncurses.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <errno.h>
#include <time.h>
#include <errno.h>

#include "common.h"
#include "patient.h"
#include "scheduler.h"
#include "resources.h"
#include "thread_worker.h"
#include "ipc.h"
#include "storage.h"

typedef struct {
    Patient *items;
    size_t count;
    int next_id;

    int doctors;
    int machines;
    int rooms;

    Algorithm alg;
    unsigned quantum_ms;
} UiState;

typedef struct {
    int idx;               // patient index in list
    unsigned start_ms;
    unsigned end_ms;
} Slice;

static const char *service_name(ServiceType s) {
    switch (s) {
        case SERVICE_CONSULTATION: return "Consultation";
        case SERVICE_LAB_TEST: return "Lab Test";
        case SERVICE_TREATMENT: return "Treatment";
        default: return "Unknown";
    }
}

static void ui_init(UiState *st) {
    memset(st, 0, sizeof(*st));
    st->items = NULL;
    st->count = 0;
    st->next_id = 1;
    st->doctors = 3;
    st->machines = 2;
    st->rooms = 4;
    st->alg = ALG_FCFS;
    st->quantum_ms = 3;
}

static void ui_init_colors(void) {
    if (!has_colors()) return;
    start_color();
    use_default_colors();
    init_pair(1, COLOR_CYAN, -1);     // headers
    init_pair(2, COLOR_YELLOW, -1);   // table headings
    init_pair(3, COLOR_GREEN, -1);    // FCFS/SJF rows
    init_pair(4, COLOR_MAGENTA, -1);  // Priority row
    init_pair(5, COLOR_BLUE, -1);     // RR row
    init_pair(6, COLOR_GREEN, -1);    // Consultation bar
    init_pair(7, COLOR_YELLOW, -1);   // Lab Test bar
    init_pair(8, COLOR_RED, -1);      // Treatment bar
}

static void add_patient(UiState *st, const char *name, int priority, ServiceType svc, unsigned req_ms, unsigned arr_ms) {
    st->items = (Patient *)realloc(st->items, sizeof(Patient) * (st->count + 1));
    Patient *p = &st->items[st->count];
    p->id = st->next_id++;
    snprintf(p->name, MAX_NAME_LEN, "%s", name);
    p->priority = priority;
    p->service = svc;
    p->required_time_ms = req_ms;
    p->arrival_ms = arr_ms;
    st->count++;
}

static Patient *find_patient(UiState *st, int id, size_t *idx_out) {
    for (size_t i = 0; i < st->count; ++i) {
        if (st->items[i].id == id) {
            if (idx_out) *idx_out = i;
            return &st->items[i];
        }
    }
    return NULL;
}

static int delete_patient(UiState *st, int id) {
    size_t idx;
    if (!find_patient(st, id, &idx)) return -1;
    for (size_t i = idx + 1; i < st->count; ++i) st->items[i-1] = st->items[i];
    st->count--;
    if (st->count == 0) {
        free(st->items); st->items = NULL;
    } else {
        st->items = (Patient *)realloc(st->items, sizeof(Patient) * st->count);
    }
    return 0;
}

static int prompt_int(const char *label, int def) {
    echo();
    curs_set(1);
    char buf[64];
    mvprintw(LINES-3, 2, "%s [%d]: ", label, def);
    getnstr(buf, sizeof(buf)-1);
    noecho();
    curs_set(0);
    if (strlen(buf) == 0) return def;
    return atoi(buf);
}

static unsigned prompt_uint(const char *label, unsigned def) {
    int v = prompt_int(label, (int)def);
    return v <= 0 ? def : (unsigned)v;
}

static void prompt_str(const char *label, char *out, size_t outsz, const char *def) {
    echo();
    curs_set(1);
    mvprintw(LINES-3, 2, "%s [%s]: ", label, def ? def : "");
    getnstr(out, (int)outsz-1);
    noecho();
    curs_set(0);
    if (strlen(out) == 0 && def) snprintf(out, outsz, "%s", def);
}

static ServiceType prompt_service(ServiceType def) {
    int cur = (int)def;
    const char *opts[] = {"Consultation", "Lab Test", "Treatment"};
    int choice = cur;
    while (1) {
        clear();
        mvprintw(1, 2, "Select Service Type:");
        for (int i = 0; i < 3; ++i) {
            if (i == choice) attron(A_REVERSE);
            mvprintw(3 + i, 4, "%s", opts[i]);
            if (i == choice) attroff(A_REVERSE);
        }
        mvprintw(LINES-2, 2, "Use Up/Down, Enter to select, q to cancel");
        int ch = getch();
        if (ch == KEY_UP) { if (choice > 0) choice--; }
        else if (ch == KEY_DOWN) { if (choice < 2) choice++; }
        else if (ch == '\n') break;
        else if (ch == 'q') return def;
    }
    return (ServiceType)choice;
}

// Build scheduling timeline slices for visualization
static Slice *build_timeline(const PatientList *list, Algorithm alg, unsigned quantum_ms, size_t *out_count) {
    size_t n = list->count;
    if (n == 0) { *out_count = 0; return NULL; }
    // Index order
    int *order = schedule_order(list, alg, quantum_ms);
    // Worst-case slice count: RR may produce many; cap to 10*n for display
    size_t cap = alg == ALG_RR ? (size_t)(10 * n) : n;
    Slice *slices = (Slice *)malloc(sizeof(Slice) * cap);
    size_t count = 0;

    if (alg == ALG_RR) {
        // RR simulation similar to compute_metrics
        unsigned *remaining = (unsigned *)malloc(sizeof(unsigned) * n);
        unsigned *arrival = (unsigned *)malloc(sizeof(unsigned) * n);
        for (size_t i = 0; i < n; ++i) { remaining[i] = list->items[i].required_time_ms; arrival[i] = list->items[i].arrival_ms; }
        // Arrival order: sort indices by arrival locally
        int *arrival_order = (int *)malloc(sizeof(int) * n);
        for (size_t i = 0; i < n; ++i) arrival_order[i] = order[i];
        // Local comparator using a static context pointer
        static const PatientList *g_ui_cmp_ctx = NULL;
        g_ui_cmp_ctx = list;
        int cmp_arrival(const void *a, const void *b) {
            int ia = *(const int *)a, ib = *(const int *)b;
            unsigned aa = g_ui_cmp_ctx->items[ia].arrival_ms;
            unsigned ab = g_ui_cmp_ctx->items[ib].arrival_ms;
            if (aa < ab) return -1; if (aa > ab) return 1; return ia - ib;
        }
        qsort(arrival_order, n, sizeof(int), cmp_arrival);
        g_ui_cmp_ctx = NULL;

        int *queue = (int *)malloc(sizeof(int) * n);
        size_t head = 0, tail = 0, qcount = 0, completed = 0, next_arrival = 0;
        unsigned time = 0;
        if (next_arrival < n) time = arrival[arrival_order[next_arrival]];

        while (completed < n && count < cap) {
            while (next_arrival < n) {
                int pid = arrival_order[next_arrival];
                if (arrival[pid] <= time) { queue[tail] = pid; tail = (tail + 1) % n; qcount++; next_arrival++; }
                else break;
            }
            if (qcount == 0) { if (next_arrival < n) { time = arrival[arrival_order[next_arrival]]; continue; } else break; }
            int pid = queue[head]; head = (head + 1) % n; qcount--;
            if (remaining[pid] == 0) continue;
            unsigned slice = remaining[pid] > quantum_ms ? quantum_ms : remaining[pid];
            unsigned start = time; time += slice; remaining[pid] -= slice;
            slices[count++] = (Slice){ .idx = pid, .start_ms = start, .end_ms = time };
            while (next_arrival < n) {
                int np = arrival_order[next_arrival];
                if (arrival[np] <= time) { queue[tail] = np; tail = (tail + 1) % n; qcount++; next_arrival++; } else break;
            }
            if (remaining[pid] > 0) { queue[tail] = pid; tail = (tail + 1) % n; qcount++; } else { completed++; }
        }
        free(remaining); free(arrival); free(arrival_order); free(queue);
    } else {
        unsigned time = 0;
        for (size_t k = 0; k < n && count < cap; ++k) {
            int i = order[k]; Patient p = list->items[i];
            if (p.arrival_ms > time) time = p.arrival_ms;
            unsigned start = time; unsigned end = start + p.required_time_ms; time = end;
            slices[count++] = (Slice){ .idx = i, .start_ms = start, .end_ms = end };
        }
    }
    free(order);
    *out_count = count;
    return slices;
}

static void draw_timeline(const PatientList *list, const Slice *slices, size_t count) {
    if (count == 0) { mvprintw(3, 2, "No timeline to display."); return; }
    unsigned max_end = 0; for (size_t i = 0; i < count; ++i) if (slices[i].end_ms > max_end) max_end = slices[i].end_ms;
    int left = 2, right = COLS - 4; int width = right - left;
    mvprintw(2, 2, "Gantt Chart (scaled to width, max %u ms)", max_end);
    mvhline(3, 2, '-', COLS-4);
    int base_row = 4;
    // Draw patient rows with colored bars by service type
    for (size_t pi = 0; pi < list->count && (base_row + (int)pi) < LINES - 3; ++pi) {
        Patient p = list->items[pi];
        mvprintw(base_row + (int)pi, 2, "%-12s", p.name);
        for (size_t si = 0; si < count; ++si) {
            if (slices[si].idx != (int)pi) continue;
            int col_start = left + (int)((double)slices[si].start_ms / max_end * width);
            int col_end = left + (int)((double)slices[si].end_ms / max_end * width);
            if (col_end <= col_start) col_end = col_start + 1;
            int color_pair = 6;
            if (p.service == SERVICE_LAB_TEST) color_pair = 7;
            else if (p.service == SERVICE_TREATMENT) color_pair = 8;
            if (has_colors()) attron(COLOR_PAIR(color_pair));
            for (int c = col_start; c < col_end && c < right; ++c) mvaddch(base_row + (int)pi, c, ACS_CKBOARD);
            if (has_colors()) attroff(COLOR_PAIR(color_pair));
        }
    }
    // Time axis (0%, 50%, 100%)
    mvprintw(base_row + (int)list->count + 1, left, "0");
    mvprintw(base_row + (int)list->count + 1, left + width/2, "%u", max_end/2);
    mvprintw(base_row + (int)list->count + 1, left + width - 3, "%u", max_end);
}

static Algorithm prompt_alg(Algorithm def) {
    const char *opts[] = {"FCFS", "SJF", "Priority", "Round Robin"};
    int choice = (int)def;
    while (1) {
        clear();
        mvprintw(1, 2, "Select Scheduling Algorithm:");
        for (int i = 0; i < 4; ++i) {
            if (i == choice) attron(A_REVERSE);
            mvprintw(3 + i, 4, "%s", opts[i]);
            if (i == choice) attroff(A_REVERSE);
        }
        mvprintw(LINES-2, 2, "Use Up/Down, Enter to select, q to cancel");
        int ch = getch();
        if (ch == KEY_UP) { if (choice > 0) choice--; }
        else if (ch == KEY_DOWN) { if (choice < 3) choice++; }
        else if (ch == '\n') break;
        else if (ch == 'q') return def;
    }
    return (Algorithm)choice;
}

static void view_patients(UiState *st) {
    clear();
    mvprintw(1, 2, "Patient Queue (%zu):", st->count);
    mvprintw(3, 2, "ID   Name                Service       Priority  Req(ms)  Arrival(ms)");
    mvhline(4, 2, '-', COLS-4);
    int row = 5;
    for (size_t i = 0; i < st->count && row < LINES-3; ++i) {
        Patient *p = &st->items[i];
        mvprintw(row++, 2, "%-4d %-18s %-12s %-8d %-8u %-10u",
                 p->id, p->name, service_name(p->service), p->priority,
                 p->required_time_ms, p->arrival_ms);
    }
    mvprintw(LINES-2, 2, "Press any key to return...");
    getch();
}

static void view_logs(void) {
    clear();
    mvprintw(1, 2, "Logs (logs/log.txt):");
    FILE *f = fopen("logs/log.txt", "r");
    if (!f) {
        mvprintw(3, 2, "No log file found yet.");
        mvprintw(LINES-2, 2, "Press any key to return...");
        getch();
        return;
    }
    char line[256];
    int row = 3;
    while (fgets(line, sizeof(line), f) && row < LINES-3) {
        mvprintw(row++, 2, "%s", line);
    }
    fclose(f);
    mvprintw(LINES-2, 2, "Press any key to return...");
    getch();
}

static void run_scheduler(UiState *st) {
    if (st->count == 0) {
        clear();
        mvprintw(3, 2, "No patients to schedule. Add patients first.");
        mvprintw(LINES-2, 2, "Press any key to return...");
        getch();
        return;
    }

    // IPC setup
    if (ipc_setup_fifo() != 0) {
        clear(); mvprintw(3, 2, "Failed to setup FIFO."); getch(); return;
    }
    mqd_t mq = ipc_open_mq(1);
    int shm_fd = -1; SharedStats *stats = NULL;
    int shm_ok = (ipc_setup_shm(&shm_fd, &stats, 1) == 0);
    if (!shm_ok) {
        // Continue without shared memory; metrics will be shown in UI and logs via FIFO
        stats = NULL;
    }

    pid_t pid = fork();
    if (pid == 0) {
        execl("bin/logger", "logger", (char *)NULL);
        _exit(127);
    }

    // Open FIFO for write with retry to avoid blocking if logger not ready
    int fifo_fd = -1;
    for (int tries = 0; tries < 200 && fifo_fd == -1; ++tries) {
        fifo_fd = open(FIFO_PATH, O_WRONLY | O_NONBLOCK);
        if (fifo_fd == -1 && errno == ENXIO) {
            // No reader yet; wait and retry
            ms_sleep(10);
            continue;
        }
    }
    if (fifo_fd == -1) {
        clear(); mvprintw(3, 2, "Failed to open FIFO (writer) — logger not ready."); getch(); return;
    }

    ResourcePool resources;
    if (resources_init(&resources, st->doctors, st->machines, st->rooms) != 0) {
        clear(); mvprintw(3, 2, "Failed to init resources."); getch(); return;
    }

    // Prepare PatientList view onto current items
    PatientList list;
    list.items = st->items;
    list.count = st->count;

    // Measure wall-clock elapsed for utilization
    struct timespec t0, t1;
    clock_gettime(CLOCK_MONOTONIC, &t0);

    int *order = schedule_order(&list, st->alg, st->quantum_ms);
    ScheduleMetrics metrics = compute_metrics(&list, order, st->alg, st->quantum_ms);

    if (stats) {
        stats->avg_wait_ms = metrics.avg_wait_ms;
        stats->avg_turnaround_ms = metrics.avg_turnaround_ms;
        stats->completed_jobs = (int)list.count;
    }
    if (mq != (mqd_t)-1 && stats) {
        mq_send(mq, "STATS_READY", strlen("STATS_READY"), 1);
    }

    pthread_t *threads = (pthread_t *)calloc(list.count, sizeof(pthread_t));
    WorkerArgs *args = (WorkerArgs *)calloc(list.count, sizeof(WorkerArgs));
    for (size_t k = 0; k < list.count; ++k) {
        int idx = order[k];
        args[k].patient = list.items[idx];
        args[k].resources = &resources;
        args[k].fifo_fd = fifo_fd;
        pthread_create(&threads[k], NULL, patient_thread, &args[k]);
        ms_sleep(10);
    }
    for (size_t k = 0; k < list.count; ++k) pthread_join(threads[k], NULL);

    clock_gettime(CLOCK_MONOTONIC, &t1);
    unsigned long long elapsed_ms = (unsigned long long)((t1.tv_sec - t0.tv_sec) * 1000ULL + (t1.tv_nsec - t0.tv_nsec) / 1000000ULL);

    free(order); free(threads); free(args);

    resources_destroy(&resources);
    close(fifo_fd);
    if (mq != (mqd_t)-1) {
        ipc_close_mq(mq);
    }
    ms_sleep(100);
    ipc_cleanup_fifo();
    if (stats) {
        munmap(stats, sizeof(*stats));
        close(shm_fd);
        ipc_cleanup_shm();
    }

    int status = 0; waitpid(pid, &status, 0);

    clear();
    mvprintw(2, 2, "Algorithm: %s", alg_name(st->alg));
    mvprintw(3, 2, "Average Waiting Time: %.2f ms", metrics.avg_wait_ms);
    mvprintw(4, 2, "Average Turnaround Time: %.2f ms", metrics.avg_turnaround_ms);
    mvprintw(6, 2, "Completed Jobs: %d", (int)list.count);
    // Utilization metrics
    double util_doctors = elapsed_ms ? (double)resources.busy_doctors_ms / (elapsed_ms * resources.num_doctors) : 0.0;
    double util_machines = elapsed_ms ? (double)resources.busy_machines_ms / (elapsed_ms * resources.num_machines) : 0.0;
    double util_rooms = elapsed_ms ? (double)resources.busy_rooms_ms / (elapsed_ms * resources.num_rooms) : 0.0;
    mvprintw(8, 2, "Utilization:");
    mvprintw(9, 4, "Doctors:  %5.1f%%", util_doctors * 100.0);
    mvprintw(10, 4, "Machines: %5.1f%%", util_machines * 100.0);
    mvprintw(11, 4, "Rooms:    %5.1f%%", util_rooms * 100.0);
    mvprintw(8, 2, "Logs saved to logs/log.txt");
    mvprintw(LINES-2, 2, "Press any key to return...");
    getch();
}

static void draw_header(UiState *st) {
    if (has_colors()) attron(COLOR_PAIR(1));
    mvprintw(1, 2, "================ HOSPITAL RESOURCE SCHEDULER ================");
    if (has_colors()) attroff(COLOR_PAIR(1));
    mvprintw(3, 2, "[1] Add Patient    [2] View Patients    [3] Update Patient");
    mvprintw(4, 2, "[4] Delete Patient [5] Run Scheduler    [6] View Logs");
    mvprintw(5, 2, "[7] Set Resources  [8] Set Algorithm    [9] Set Quantum");
    mvprintw(6, 2, "[g] Generate N Patients  [s] Save CSV  [l] Load CSV  [c] Clear List");
    mvprintw(7, 2, "[x] Compare Algorithms    [q] Exit");
    mvhline(8, 2, '-', COLS-4);
    if (has_colors()) attron(COLOR_PAIR(2));
    mvprintw(9, 2, "Doctors: %d   Machines: %d   Rooms: %d", st->doctors, st->machines, st->rooms);
    mvprintw(10, 2, "Algorithm: %s   Quantum: %u ms", alg_name(st->alg), st->quantum_ms);
    if (has_colors()) attroff(COLOR_PAIR(2));
    mvhline(11, 2, '-', COLS-4);
}

int main(void) {
    UiState st; ui_init(&st);

    initscr();
    cbreak();
    noecho();
    keypad(stdscr, TRUE);
    curs_set(0);
    ui_init_colors();

    int running = 1;
    while (running) {
        clear();
        draw_header(&st);
        mvprintw(13, 2, "Patient Queue: %zu", st.count);
        mvprintw(LINES-2, 2, "Select an option...");
        int ch = getch();
        switch (ch) {
            case '1': {
                clear(); draw_header(&st);
                char name[MAX_NAME_LEN]; name[0] = '\0';
                prompt_str("Name", name, sizeof(name), "Patient");
                ServiceType svc = prompt_service(SERVICE_CONSULTATION);
                int pri = prompt_int("Priority (1..5)", 3);
                if (pri < 1) pri = 1; if (pri > 5) pri = 5;
                unsigned req = prompt_uint("Required Time (ms)", 300);
                unsigned arr = prompt_uint("Arrival Time (ms)", 0);
                if (strlen(name) == 0) snprintf(name, sizeof(name), "Patient_%02d", st.next_id);
                add_patient(&st, name, pri, svc, req, arr);
                break;
            }
            case '2': {
                view_patients(&st);
                break;
            }
            case '3': {
                int id = prompt_int("Update Patient ID", 1);
                size_t idx; Patient *p = find_patient(&st, id, &idx);
                if (!p) { clear(); mvprintw(3, 2, "Patient not found."); getch(); break; }
                char name[MAX_NAME_LEN]; snprintf(name, sizeof(name), "%s", p->name);
                prompt_str("Name", name, sizeof(name), p->name);
                p->service = prompt_service(p->service);
                p->priority = prompt_int("Priority (1..5)", p->priority);
                if (p->priority < 1) p->priority = 1; if (p->priority > 5) p->priority = 5;
                p->required_time_ms = prompt_uint("Required Time (ms)", p->required_time_ms);
                p->arrival_ms = prompt_uint("Arrival Time (ms)", p->arrival_ms);
                snprintf(p->name, MAX_NAME_LEN, "%s", name);
                break;
            }
            case '4': {
                int id = prompt_int("Delete Patient ID", 1);
                if (delete_patient(&st, id) != 0) { clear(); mvprintw(3, 2, "Patient not found."); getch(); }
                break;
            }
            case '5': {
                run_scheduler(&st);
                break;
            }
            case '6': {
                view_logs();
                break;
            }
            case '7': {
                st.doctors = prompt_int("Doctors", st.doctors);
                st.machines = prompt_int("Machines", st.machines);
                st.rooms = prompt_int("Rooms", st.rooms);
                break;
            }
            case '8': {
                st.alg = prompt_alg(st.alg);
                break;
            }
            case '9': {
                st.quantum_ms = prompt_uint("Quantum (ms)", st.quantum_ms);
                break;
            }
            case 'g': {
                int n = prompt_int("Generate N patients", 5);
                for (int i = 0; i < n; ++i) {
                    char name[MAX_NAME_LEN];
                    snprintf(name, sizeof(name), "Patient_%02d", st.next_id);
                    ServiceType svc = (ServiceType)(rand() % 3);
                    int pri = (rand() % 5) + 1;
                    unsigned req = (unsigned)(100 + (rand() % 900));
                    unsigned arr = (unsigned)(rand() % 500);
                    add_patient(&st, name, pri, svc, req, arr);
                }
                break;
            }
            case 's': {
                // Save to CSV
                char path[256]; snprintf(path, sizeof(path), "data/patients.csv");
                PatientList list; list.items = st.items; list.count = st.count;
                if (save_patients_csv(path, &list) == 0) {
                    clear(); mvprintw(3, 2, "Saved %zu patients to %s", st.count, path);
                } else {
                    clear(); mvprintw(3, 2, "Failed to save to %s", path);
                }
                mvprintw(LINES-2, 2, "Press any key to return..."); getch();
                break;
            }
            case 'l': {
                // Load from CSV
                char path[256]; snprintf(path, sizeof(path), "data/patients.csv");
                PatientList loaded = {0};
                if (load_patients_csv(path, &loaded) == 0) {
                    // Replace current list
                    free(st.items);
                    st.items = loaded.items;
                    st.count = loaded.count;
                    // Update next_id
                    int max_id = 0; for (size_t i = 0; i < st.count; ++i) if (st.items[i].id > max_id) max_id = st.items[i].id;
                    st.next_id = max_id + 1;
                    clear(); mvprintw(3, 2, "Loaded %zu patients from %s", st.count, path);
                } else {
                    clear(); mvprintw(3, 2, "Failed to load from %s", path);
                }
                mvprintw(LINES-2, 2, "Press any key to return..."); getch();
                break;
            }
            case 'c': {
                free(st.items); st.items = NULL; st.count = 0; st.next_id = 1;
                clear(); mvprintw(3, 2, "Patient list cleared.");
                mvprintw(LINES-2, 2, "Press any key to return..."); getch();
                break;
            }
            case 'x': {
                // Compare algorithms table
                PatientList list; list.items = st.items; list.count = st.count;
                Algorithm algs[4] = { ALG_FCFS, ALG_SJF, ALG_PRIORITY, ALG_RR };
                const char *names[4] = { "FCFS", "SJF", "Priority", "Round Robin" };
                ScheduleMetrics mets[4];
                int *order = NULL;
                clear();
                if (has_colors()) attron(COLOR_PAIR(1));
                mvprintw(2, 2, "Algorithm Comparison (N=%zu, Quantum=%u ms):", list.count, st.quantum_ms);
                if (has_colors()) attroff(COLOR_PAIR(1));
                mvhline(3, 2, '-', COLS-4);
                if (has_colors()) attron(COLOR_PAIR(2));
                mvprintw(4, 2, "%-14s %-20s %-22s", "Algorithm", "Avg Wait (ms)", "Avg Turnaround (ms)");
                if (has_colors()) attroff(COLOR_PAIR(2));
                mvhline(5, 2, '-', COLS-4);
                for (int i = 0; i < 4; ++i) {
                    order = schedule_order(&list, algs[i], st.quantum_ms);
                    mets[i] = compute_metrics(&list, order, algs[i], st.quantum_ms);
                    free(order);
                    int row = 6 + i; int pair = (i == 3 ? 5 : (i == 2 ? 4 : 3));
                    if (has_colors()) attron(COLOR_PAIR(pair));
                    mvprintw(row, 2, "%-14s %-20.2f %-22.2f", names[i], mets[i].avg_wait_ms, mets[i].avg_turnaround_ms);
                    if (has_colors()) attroff(COLOR_PAIR(pair));
                }
                mvprintw(LINES-2, 2, "Press any key to return..."); getch();
                break;
            }
            case 'v': {
                // View simulation (Gantt chart) for selected algorithm
                Algorithm a = prompt_alg(st.alg);
                PatientList list; list.items = st.items; list.count = st.count;
                size_t sc = 0; Slice *sl = build_timeline(&list, a, st.quantum_ms, &sc);
                clear();
                mvprintw(1, 2, "Simulation: %s", alg_name(a));
                draw_timeline(&list, sl, sc);
                mvprintw(LINES-2, 2, "Press any key to return..."); getch();
                free(sl);
                break;
            }
            case 'q':
            case 'Q':
                running = 0; break;
            default:
                break;
        }
    }

    endwin();
    free(st.items);
    return 0;
}
